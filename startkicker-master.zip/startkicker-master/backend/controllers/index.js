module.exports = {
  auth: require('./auth'),
  pay: require('./pay'),
  project: require('./project'),
  plan: require('./plan'),
  user: require('./user'),
 
};
