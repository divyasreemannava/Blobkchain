import React from 'react';
import { Container, Nav } from 'react-bootstrap';
import './Footer.css'

const Footer = props => {
  return (
    <div>
      <div className="footer">
      <div className="content">
        made with love by amazingshellyyy
      </div>
      </div>
    </div>
  )
}

export default Footer;